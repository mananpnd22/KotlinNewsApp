package com.manan.test.kotlinnews.presentation

interface BaseView
